﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace пр11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Student stud = new Student();
            stud.name = textBox1.Text;
            stud.rost = (double)numericUpDown1.Value;
            int food = 1;
            stud.SetEat(food);
            MessageBox.Show(string.Format("Student:{0} Еды съеденно:{3} \nрост: {1} \nves:{2}", stud.name, stud.rost, stud.GetEat(),food));
            food = 5;
            stud.SetEat(food);
            MessageBox.Show(string.Format("Student:{0} Еды съеденно:{3} \nрост: {1} \nves:{2}", stud.name, stud.rost, stud.GetEat(), food));
        }
    }

    public class Student
    {
        public string name;
        public double rost;
        private double ves=50;

        public double GetEat()
        {
            return ves;
        }

        public double SetEat(double food)
        {
            if (food >= 5 && food < 10)
            {
                ves += (food * 1000 - 1600) * 0.7;
                rost--;
                return ves;
            }
            else if (food >= 10)
            {
                ves += (food*1000-1800)*0.5;
                rost -= 2;
                return ves;
            }
            else
            {
                ves = ves + food - 2800 / 1000;
                return ves;
            }
        }

    }
}
